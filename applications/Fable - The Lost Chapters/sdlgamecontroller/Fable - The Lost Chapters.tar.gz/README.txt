Button Assignments based on the Original Fable controls. This profile is setup to work with the WASD keys by default which can be set in game.

The menu can be controlled through the right stick as the mouse, X being Left Click and B being Right Click.

ASSIGNMENTS:
Left Stick: Movement
Left Stick Click: Sneak
Right Stick: Camera Control
Right Stick Click: Map
D-Pad: Hotbar Items 1-4 (up=1, right=2, down=3, left=4)
A: Interact
B: Run
X: Attack
Y: Block
Back: Inventory (Items by Default)
Start: Pause
Left Shoulder: Arm/Sheathe Ranged Weapon
Left Trigger: Target Lock-on
Right Shoulder: Arm/Sheathe Melee Weapon
Right Trigger: Collection Experience Orbs/Magic