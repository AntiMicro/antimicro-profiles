Author: Jacob-Mischka

Here's one I am using to play the Steam Jet Set Radio remake in WINE since it doesn't recognize the controller. For what it's worth, the game's controls are absolutely horrible even when using a recognized controller, and even worse when using the keyboard/mouse or emulating m/k events. Anyway.

Left Stick - Movement (W, A, S, D)
Right Stick - Camera Control (Mouse) [Pretty buggy and unresponsive in the game itself]
DPad - Movement (Up, Down, Left, Right) [Arrow keys behave exactly the same as WASD for the game/menus]
Left Trigger - Center Camera/Spray (Q)
Right Trigger - Boost (E)
Start - Pause (Enter)
A - Jump/Confirm (Space)
B - Cancel (Esc)
Guide - Steam Overlay (Shift+Tab)
