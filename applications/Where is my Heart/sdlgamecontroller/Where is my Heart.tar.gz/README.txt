This profile is setup to work with the default keyboard settings in the game.

ASSIGNMENTS:
Left Stick: Movement (Top / Right / Bottom / Left)
A: Jump / Confirm (Space)
X: Switch (D)
Start: Menu / Back (Esc)
Left Shoulder: Rotation Left (A)
Right Shoulder: Rotation Right (S)
